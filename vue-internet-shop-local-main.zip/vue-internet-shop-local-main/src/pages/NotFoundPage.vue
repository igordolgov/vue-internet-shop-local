<template>
  <h1>
    Страница не найдена
  </h1>
</template>

<script>
export default {
};
</script>

<style>
  h1 {
    margin: auto;
  }
</style>
